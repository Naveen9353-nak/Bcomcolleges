import React, { useState } from "react";
import { Box, Typography, Tab, Tabs, Card, CardContent, Button } from "@mui/material";

const BComCourses = () => {
  const [selectedTab, setSelectedTab] = useState(0); 

  const courses = [
    {
      name: "BCom General",
      description:
        "A comprehensive undergraduate program focusing on core business subjects such as accounting, economics, and management.",
      specialization: "General",
    },
    {
      name: "BCom in Accounting and Finance",
      description:
        "This specialization covers advanced topics in accounting, financial analysis, taxation, and auditing.",
      specialization: "Accounting and Finance",
    },
    {
      name: "BCom in Computer Applications",
      description:
        "This course offers a blend of business knowledge with IT, including subjects like programming, database management, and e-commerce.",
      specialization: "Computer Applications",
    },
    {
      name: "BCom in Banking and Insurance",
      description:
        "Focuses on the banking sector, financial services, and the insurance industry, covering topics like risk management and banking operations.",
      specialization: "Banking and Insurance",
    },
    {
      name: "BCom in International Business",
      description:
        "Explores international trade, global marketing, and cross-border financial transactions, preparing students for a global business environment.",
      specialization: "International Business",
    },
  ];

  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue); 
  };

  return (
    <Box sx={{ padding: "20px" }}>
      <Typography variant="h4" sx={{ marginBottom: "20px", textAlign: "center" }}>
        BCom Courses Offered
      </Typography>

      {/* Tabs for course selection */}
      <Tabs
        value={selectedTab}
        onChange={handleTabChange}
        indicatorColor="primary"
        textColor="primary"
        centered
        sx={{ marginBottom: "20px" }}
      >
        {courses.map((course, index) => (
          <Tab label={course.name} key={index} />
        ))}
      </Tabs>

      {/* Display selected course details */}
      <Card>
        <CardContent>
          <Typography variant="h5" sx={{ fontWeight: "bold" }}>
            {courses[selectedTab].name}
          </Typography>
          <Typography variant="body1" sx={{ marginTop: "10px" }}>
            {courses[selectedTab].description}
          </Typography>
          <Typography variant="body2" sx={{ fontStyle: "italic", marginTop: "10px" }}>
            Specialization: {courses[selectedTab].specialization}
          </Typography>
          <Button
            variant="contained"
            color="primary"
            sx={{ marginTop: "20px" }}
            onClick={() => alert(`Details of ${courses[selectedTab].name}`)}
          >
            Learn More
          </Button>
        </CardContent>
      </Card>
    </Box>
  );
};

export default BComCourses;
